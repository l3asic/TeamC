package pack99_Test;

import java.awt.print.Printable;
import java.util.Scanner;

public class JapangiDAO {

	Scanner sc = new Scanner(System.in);

	int display(JapangiDTO[] dtos, int money) {

		Scanner sc = new Scanner(System.in);

		System.out.println("\t" + "���ֱ� or ���ἱ�� or ����");

		int sumMoney = 0;

		while (true) {
			String inputData = sc.nextLine();

			if (inputData.equals("10") || inputData.equals("50") || inputData.equals("100") || inputData.equals("500")	
					|| inputData.equals("1000") || inputData.equals("5000") || inputData.equals("10000")) {
				int inputMoney = Integer.parseInt(inputData);
				System.out.println("\t" + "+++++!!"+inputMoney + "�� ����.\t");
				sumMoney += inputMoney;

				System.out.print("\t" + "=====!!�ܾ�\t");
				System.out.println("\t" + "<!!<" + sumMoney + ">!!>");

				// dao.inputMoney();
			} else if (inputData.equals("cola")) {
				System.out.println("\t" + "cola �Էµ�");

				if (sumMoney >= dtos[0].price && dtos[0].count != 0) {
					System.out.println("\t" + "cola���");
					sumMoney -= dtos[0].price;
					dtos[0].count--;
					System.out.println("\t" + "");
					System.out.println("\t" + "\t ��������");
					for(int i=0; i<dtos.length;i++){
						System.out.println("\t" + dtos[i].name +"\t"+ dtos[i].price +"\t"+ dtos[i].count);
						}
					System.out.println("\t" + "=====!!"+"�ܾ� " + "<!!<" + sumMoney + ">!!>");
				} else {
					System.out.println("\t" + "cola��¿���");

				}
			} else if (inputData.equals("cider")) {
				System.out.println("\t" + "cider �Էµ�");

				if (sumMoney >= dtos[1].price && dtos[1].count != 0) {
					System.out.println("\t" + "cider���");
					sumMoney -= dtos[1].price;
					dtos[1].count--;
					System.out.println("\t" + "");
					System.out.println("\t" + "\t ��������");
					for(int i=0; i<dtos.length;i++){
						System.out.println("\t" + dtos[i].name +"\t"+ dtos[i].price +"\t"+ dtos[i].count);
						}
					System.out.println("\t" + "=====!!"+"�ܾ� " + "<!!<" + sumMoney + ">!!>");
				} else {
					System.out.println("\t" + "cider��¿���");

				}
			} else if (inputData.equals("fanta")) {
				System.out.println("\t" + "fanta �Էµ�");

				if (sumMoney >= dtos[2].price && dtos[2].count != 0) {
					System.out.println("\t" + "fanta���");
					sumMoney -= dtos[2].price;
					dtos[2].count--;
					System.out.println("\t" + "");
					System.out.println("\t" + "\t ��������");
					for(int i=0; i<dtos.length;i++){
						System.out.println("\t" + dtos[i].name +"\t"+ dtos[i].price +"\t"+ dtos[i].count);
						}
					System.out.println("\t" + "=====!!"+"�ܾ� " + "<!!<" + sumMoney + ">!!>");
				} else {
					System.out.println("\t" + "fanta��¿���");

				}

			} else if (inputData.equals("lever")) {
				System.out.println("\t" + "���� �Էµ� - �ܵ���ȯ ����");
				int abc = sumMoney;
				sumMoney = 0;
				System.out.println("\t" + "�ܵ�" + abc + "��ȯ����");
				int a1 = abc / 10000;
				int a2 = (abc % 10000) / 5000;
				int a3 = ((abc % 10000) % 5000) / 1000;
				int a4 = (((abc % 10000) % 5000) % 1000) / 500;
				int a5 = ((((abc % 10000) % 5000) % 1000) % 500) / 100;
				int a6 = (((((abc % 10000) % 5000) % 1000) % 500) % 100) / 50;
				int a7 = ((((((abc % 10000) % 5000) % 1000) % 500) % 100) % 50) / 10;
				System.out.println("\t" + "������"+a1 + "    " + "��õ����"+a2 + "    " + "õ����"+a3 + "    " + "�����"+a4 + "    " + "���"+a5 + "    " + "���ʿ�"+a6 + "    " + "�ʿ�"+a7);
				System.out.print("\t" + "=====!!�ܾ� \t");
				System.out.println("\t" + "<!!<" + sumMoney + ">!!>");
			} else if (inputData.equals("")) {
				System.out.println("\t" + "�ƹ��͵� �Է����� �ʾ���");
			} else if (inputData.equals("�����ڸ��")) {
				System.out.println("\t" + "������ ID �Է�");
			} else {
				System.out.println("\t" + "�߸��Է���");
			}

		}
	}
	
	boolean adminLogIn() {
		
		String adminID = "master";
		String adminPW = "admin";
		
		System.out.println("ID�Է�");
		String inputID = sc.nextLine();
		System.out.println("PW�Է�");
		String inputPW = sc.nextLine();
		
		if(inputID.equals(adminID) && inputPW.equals(adminPW)){
			System.out.println("==!!= O O O =ID PW ��ġ= O O O =!!==");
			return true;
		}else {System.out.println("==!!= X X X =IW PW ����ġ= X X X =!!==");
			return false;
		}
	}
	
	void adminMenu(){
		System.out.println("�����ڸ޴� ���");
		
	}
	
	
	
}
// inputData.equals("cider") || inputData.equals("fanta")
/*
 * dao.inputMoney();
 * 
 * dao.select();
 * 
 * dao.end();
 * 
 * dao.shutDown();
 */