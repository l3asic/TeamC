CREATE TABLE correctanswer_C(

  CA1   VARCHAR2(10 BYTE) not null,
  CA2	  VARCHAR2(10 BYTE) not null,
  CA3	  VARCHAR2(10 BYTE) not null,
  CA4	  VARCHAR2(10 BYTE) not null,
  CA5	  VARCHAR2(10 BYTE) not null,
  CA6	  VARCHAR2(10 BYTE) not null,
  CA7	  VARCHAR2(10 BYTE) not null,
  CA8	  VARCHAR2(10 BYTE) not null,
  CA9	  VARCHAR2(10 BYTE) not null,
  CA10	VARCHAR2(10 BYTE) not null

);

desc correctanswer_C;

