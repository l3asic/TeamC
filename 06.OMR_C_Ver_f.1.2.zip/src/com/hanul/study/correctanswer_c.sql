CREATE TABLE correctanswer_C(

--  subCode Varchar2(20 BYTE)   PRIMARY KEY,
  CA1   NUMBER not null,
  CA2	  NUMBER not null,
  CA3	  NUMBER not null,
  CA4	  NUMBER not null,
  CA5	  NUMBER not null,
  CA6	  NUMBER not null,
  CA7	  NUMBER not null,
  CA8	  NUMBER not null,
  CA9	  NUMBER not null,
  CA10	NUMBER not null

);


insert into correctanswer_C values (4,2,1,4,4,2,4,2,3,4);

commit;