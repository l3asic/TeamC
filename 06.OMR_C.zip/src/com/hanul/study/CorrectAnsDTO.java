package com.hanul.study;

public class CorrectAnsDTO {
	int ca1, ca2, ca3, ca4, ca5, ca6, ca7, ca8, ca9, ca10;

	public CorrectAnsDTO(int ca1, int ca2, int ca3, int ca4, int ca5, int ca6, int ca7, int ca8, int ca9, int ca10) {
		super();
		this.ca1 = ca1;
		this.ca2 = ca2;
		this.ca3 = ca3;
		this.ca4 = ca4;
		this.ca5 = ca5;
		this.ca6 = ca6;
		this.ca7 = ca7;
		this.ca8 = ca8;
		this.ca9 = ca9;
		this.ca10 = ca10;
	}

	public int getCa1() {
		return ca1;
	}

	public void setCa1(int ca1) {
		this.ca1 = ca1;
	}

	public int getCa2() {
		return ca2;
	}

	public void setCa2(int ca2) {
		this.ca2 = ca2;
	}

	public int getCa3() {
		return ca3;
	}

	public void setCa3(int ca3) {
		this.ca3 = ca3;
	}

	public int getCa4() {
		return ca4;
	}

	public void setCa4(int ca4) {
		this.ca4 = ca4;
	}

	public int getCa5() {
		return ca5;
	}

	public void setCa5(int ca5) {
		this.ca5 = ca5;
	}

	public int getCa6() {
		return ca6;
	}

	public void setCa6(int ca6) {
		this.ca6 = ca6;
	}

	public int getCa7() {
		return ca7;
	}

	public void setCa7(int ca7) {
		this.ca7 = ca7;
	}

	public int getCa8() {
		return ca8;
	}

	public void setCa8(int ca8) {
		this.ca8 = ca8;
	}

	public int getCa9() {
		return ca9;
	}

	public void setCa9(int ca9) {
		this.ca9 = ca9;
	}

	public int getCa10() {
		return ca10;
	}

	public void setCa10(int ca10) {
		this.ca10 = ca10;
	}
	
	
}
