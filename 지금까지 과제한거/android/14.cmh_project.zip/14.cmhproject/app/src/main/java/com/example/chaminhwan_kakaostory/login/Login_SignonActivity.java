package com.example.chaminhwan_kakaostory.login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.chaminhwan_kakaostory.R;

public class Login_SignonActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_signon);
    }
}