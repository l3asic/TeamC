package pack99_Test;

import java.util.Scanner;
import java.util.Arrays;

public class JapangiMAIN {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int money = 0;
		JapangiDTO dtos[] = new JapangiDTO[3];
		dtos[0] = new JapangiDTO("cola", 800, 8);
		dtos[1] = new JapangiDTO("cider", 1000, 5);
		dtos[2] = new JapangiDTO("fanta", 900, 1);
		boolean asd = false;


		JapangiDAO dao = new JapangiDAO();

		System.out.println("�̸� \t ���� \t �ܿ�����");

		for (int i = 0; i < dtos.length; i++) {
			System.out.print(dtos[i].name + "\t");
			System.out.print(dtos[i].price + "\t");
			System.out.println(dtos[i].count);
		}
		
		System.out.println("==����99==�Է½ÿ��� �����ڸ�� dao.����");
		int start = Integer.parseInt(sc.nextLine());
		if(start==99) {
			System.out.println("�����ڸ�� ����");
			System.out.println(dao.adminLogIn());
		}else {dao.display(dtos, money);
		}
		
		while(true) {
		if(asd==true) {
			dao.adminMenu();
		}else if(asd==false) {
			System.out.println("�����ڸ�� �����");
			System.out.println(dao.adminLogIn());
		}

		}
	}
}

/*
 * dao.Jpg();
 * 
 * dao.inputMoney();
 * 
 * dao.select();
 * 
 * dao.end();
 * 
 * dao.shutDown();
 */

//JapangiDAO dao = new JapangiDAO();