package com.hanul.study;

public class CorrectAnsDTO {
	String ca1, ca2, ca3, ca4, ca5, ca6, ca7, ca8, ca9, ca10;

	public CorrectAnsDTO(String ca1, String ca2, String ca3, String ca4, String ca5, String ca6, String ca7, String ca8,
			String ca9, String ca10) {
		super();
		this.ca1 = ca1;
		this.ca2 = ca2;
		this.ca3 = ca3;
		this.ca4 = ca4;
		this.ca5 = ca5;
		this.ca6 = ca6;
		this.ca7 = ca7;
		this.ca8 = ca8;
		this.ca9 = ca9;
		this.ca10 = ca10;
	}

	public String getCa1() {
		return ca1;
	}

	public void setCa1(String ca1) {
		this.ca1 = ca1;
	}

	public String getCa2() {
		return ca2;
	}

	public void setCa2(String ca2) {
		this.ca2 = ca2;
	}

	public String getCa3() {
		return ca3;
	}

	public void setCa3(String ca3) {
		this.ca3 = ca3;
	}

	public String getCa4() {
		return ca4;
	}

	public void setCa4(String ca4) {
		this.ca4 = ca4;
	}

	public String getCa5() {
		return ca5;
	}

	public void setCa5(String ca5) {
		this.ca5 = ca5;
	}

	public String getCa6() {
		return ca6;
	}

	public void setCa6(String ca6) {
		this.ca6 = ca6;
	}

	public String getCa7() {
		return ca7;
	}

	public void setCa7(String ca7) {
		this.ca7 = ca7;
	}

	public String getCa8() {
		return ca8;
	}

	public void setCa8(String ca8) {
		this.ca8 = ca8;
	}

	public String getCa9() {
		return ca9;
	}

	public void setCa9(String ca9) {
		this.ca9 = ca9;
	}

	public String getCa10() {
		return ca10;
	}

	public void setCa10(String ca10) {
		this.ca10 = ca10;
	}

}
