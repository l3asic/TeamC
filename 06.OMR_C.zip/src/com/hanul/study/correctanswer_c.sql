CREATE TABLE correctanswer_C(

  CA1   NUMBER,
  CA2	  NUMBER,
  CA3	  NUMBER,
  CA4	  NUMBER,
  CA5	  NUMBER,
  CA6	  NUMBER,
  CA7	  NUMBER,
  CA8	  NUMBER,
  CA9	  NUMBER,
  CA10	NUMBER

);

desc correctanswer_C;

