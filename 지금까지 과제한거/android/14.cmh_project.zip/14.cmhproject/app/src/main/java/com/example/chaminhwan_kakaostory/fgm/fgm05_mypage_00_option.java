package com.example.chaminhwan_kakaostory.fgm;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.chaminhwan_kakaostory.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;


public class fgm05_mypage_00_option extends Fragment {


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fgm05_mypage_00_option, container, false);
    }
}